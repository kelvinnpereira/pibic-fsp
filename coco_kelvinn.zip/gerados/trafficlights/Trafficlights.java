public class Trafficlights{

    Trafficlights(){
    }

    public void red(){
    }

    public void orange(){
    }

    public void green(){
    }

}
