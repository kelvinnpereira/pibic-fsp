public class On{

    On(){
    }

    public void off(){
    }

}
