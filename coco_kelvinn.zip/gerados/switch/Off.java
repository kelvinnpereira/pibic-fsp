public class Off{

    Off(){
    }

    public void on(){
    }

}
