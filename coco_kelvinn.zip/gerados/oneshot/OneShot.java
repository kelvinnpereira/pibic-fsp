public class OneShot{

    OneShot(){
    }

    public void once(){
        System.exit(1);
    }

}
