public class Chan{

    Chan(){
    }

    public void in(){
    }

    public void out(){
    }

}
