public class Drinks{

    Drinks(){
    }

    public void red(){
    }

    public void cofee(){
    }

    public void blue(){
    }

    public void tea(){
    }

}
