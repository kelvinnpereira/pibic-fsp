public class Runnable{

    Runnable(){
    }

    public void suspend(){
    }

    public void dispatch(){
    }

    public void stop(){
        System.exit(1);
    }

}
