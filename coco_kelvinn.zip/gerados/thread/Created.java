public class Created{

    Created(){
    }

    public void start(){
    }

    public void stop(){
        System.exit(1);
    }

}
