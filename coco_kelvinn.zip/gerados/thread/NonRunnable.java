public class NonRunnable{

    NonRunnable(){
    }

    public void resume(){
    }

    public void stop(){
        System.exit(1);
    }

}
