public class Running{

    Running(){
    }

    public void suspend(){
    }

    public void sleep(){
    }

    public void yield(){
    }

    public void stop(){
        System.exit(1);
    }

    public void end(){
    }

    public void run(){
    }

}
