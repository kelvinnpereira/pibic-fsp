public class Coin{

    Coin(){
    }

    public void toss(){
    }

    public void heads(){
    }

    public void tails(){
    }

}
